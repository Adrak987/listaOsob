﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListaOsob
{
    internal class ListaGier
    {
        public ObservableCollection<Gra> gry;

        public ListaGier()
        {
            gry = new ObservableCollection<Gra>();
            LoadGames("plik.txt");
        }

        public void AddGame(Gra gra)
        {
            gry.Add(gra);
        }
        public void RemoveGame(Gra gra)
        {
            gry.Remove(gra);
        }
        public void EditGame(int index, Gra gra)
        {
            gry[index] = gra;
        }
        public void RemoveGameAt(int index)
        {
            if(index >= 0 && index < gry.Count)
            {
                gry.RemoveAt(index);
            }
        }
        public void LoadGames(string file)
        {
            gry.Clear();
            gry.Add(new Gra("xd", "xdd", Rodzaj.Survival));
            gry.Add(new Gra("xd", "xdd", Rodzaj.Survival));
            gry.Add(new Gra("xd", "xdd", Rodzaj.Survival));
            
        }
        public void SaveGames(string file)
        {

        }
    }
}
