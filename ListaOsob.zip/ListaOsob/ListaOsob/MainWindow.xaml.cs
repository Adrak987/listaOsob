﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ListaOsob
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ListaGier listaGier = new ListaGier();
        public MainWindow()
        {
            InitializeComponent();
            rodzaj.ItemsSource = Enum.GetValues(typeof(Rodzaj)).Cast<Rodzaj>();
            listBox.ItemsSource = listaGier.gry;
        }

        private void Dodaj(object sender, RoutedEventArgs e)
        {
            Rodzaj rodzaj1 = Rodzaj.MMO;
            if(!(rodzaj.SelectedItem is null))
            {
                rodzaj1 = Enum.Parse<Rodzaj>(rodzaj.SelectedItem.ToString());
            }

            listaGier.AddGame(new Gra(nazwa.Text, tworca.Text, rodzaj1));
        }

        private void Edytuj(object sender, RoutedEventArgs e)
        {


            Rodzaj rodzaj1 = Rodzaj.MMO;
            if (!(rodzaj.SelectedItem is null))
            {
                rodzaj1 = Enum.Parse<Rodzaj>(rodzaj.SelectedItem.ToString());
            }

            
            if(!(listBox.SelectedIndex == -1))
            {
                listaGier.EditGame(listBox.SelectedIndex, new Gra(nazwa.Text, tworca.Text, rodzaj1));
            }
            
            
        }

        private void Usun(object sender, RoutedEventArgs e)
        {
            listaGier.RemoveGameAt(listBox.SelectedIndex);
        }
    }
}
