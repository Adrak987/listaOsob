﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListaOsob
{
    internal class Gra
    {
        public string Nazwa { get; set; } = string.Empty;
        public string Tworca { get; set; } = string.Empty;
        public Rodzaj Rodzaj { get; set; } = 0;

        public Gra()
        {

        }

        public Gra(string nazwa, string tworca, Rodzaj rodzaj)
        {
            Nazwa = nazwa;
            Tworca = tworca;
            Rodzaj = rodzaj;
        }

        public override string ToString()
        {
            return Nazwa + " " + Tworca + " " + Rodzaj.ToString();
        }
    }
    




    enum Rodzaj
    {
        FPS = 0,
        MMO = 1,
        Survival = 2,
    }
}
